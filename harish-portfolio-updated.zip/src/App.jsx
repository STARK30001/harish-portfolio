
import Header from "./components/Header";
import Hero from "./components/Hero";
import About from "./components/About";
import Education from "./components/Education";
import Skills from "./components/Skills";
import Internship from "./components/Internship";
import Contact from "./components/Contact";

export default function App() {
  return (
    <div className="font-sans text-gray-900 bg-white dark:bg-gray-900 dark:text-white transition-all">
      <Header />
      <Hero />
      <About />
      <Skills />
      <Education />
      <Internship />
      <Contact />
    </div>
  );
}
