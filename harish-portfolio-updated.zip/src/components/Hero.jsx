
export default function Hero() {
  return (
    <section className="min-h-screen flex flex-col justify-center items-center text-center bg-gray-100 dark:bg-gray-800">
      <h2 className="text-4xl md:text-6xl font-bold">Hi, I'm Harish</h2>
      <p className="mt-4 text-lg md:text-xl text-gray-700 dark:text-gray-300">
        Python Full Stack Developer | AWS & DevOps Intern
      </p>
    </section>
  );
}
