
export default function About() {
  return (
    <section id="about" className="p-8 max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold mb-4">About Me</h2>
      <p>
        Aim to work in a challenging environment where I can utilize my expertise in technical skills
        towards the development of an organization, implement my innovative ideas, and contribute to
        the growth of the organization and myself.
      </p>
    </section>
  );
}
