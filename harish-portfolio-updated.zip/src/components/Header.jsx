
export default function Header() {
  return (
    <header className="p-4 shadow-md sticky top-0 bg-white dark:bg-gray-800 z-10 flex justify-between items-center">
      <h1 className="text-xl font-bold">Harish Sadhili</h1>
      <nav className="space-x-4">
        <a href="#about">About</a>
        <a href="#skills">Skills</a>
        <a href="#education">Education</a>
        <a href="#internship">Internships</a>
        <a href="#contact">Contact</a>
      </nav>
    </header>
  );
}
