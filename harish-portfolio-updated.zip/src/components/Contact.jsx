
export default function Contact() {
  return (
    <section id="contact" className="p-8 max-w-xl mx-auto">
      <h2 className="text-3xl font-bold mb-4">Contact Me</h2>
      <div className="space-y-2">
        <p>Email: <a href="mailto:sadhiliharish@gmail.com" className="text-blue-500 underline">sadhiliharish@gmail.com</a></p>
        <p>Location: Madanapalle, Andhra Pradesh</p>
        <p>
          <a href="https://www.linkedin.com/in/harish-s-b3a6492b7" target="_blank" className="text-blue-500 underline">LinkedIn</a> |
          <a href="https://github.com/STARK30001" target="_blank" className="text-blue-500 underline ml-2">GitHub</a> |
          <a href="https://x.com/mr_stark__3000" target="_blank" className="text-blue-500 underline ml-2">Twitter</a> |
          <a href="https://www.instagram.com/mr_stark__3000/" target="_blank" className="text-blue-500 underline ml-2">Instagram</a> |
          <a href="https://www.facebook.com/share/1FjuJA6E5f/" target="_blank" className="text-blue-500 underline ml-2">Facebook</a>
        </p>
        <p>
          <a href="https://share.google/ItqAr822ePQ9cwVEK" className="text-green-500 underline" download>Download My Resume</a>
        </p>
      </div>
    </section>
  );
}
