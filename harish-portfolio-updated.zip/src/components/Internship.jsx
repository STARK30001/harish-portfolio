
export default function Internship() {
  return (
    <section id="internship" className="p-8 bg-gray-50 dark:bg-gray-700">
      <h2 className="text-3xl font-bold mb-4">Internships & Certifications</h2>
      <ul className="space-y-3">
        <li>AWS & DevOps Certificate – Karna HR Solutions, Tirupati (Aug 2023 - Sep 2023)</li>
        <li>Python Full Stack – DIVITH Tech Solutions, Bengaluru (Jan 2024 - May 2024)</li>
        <li>Data Analytics Workshop Certificate</li>
      </ul>
    </section>
  );
}
