
export default function Skills() {
  return (
    <section id="skills" className="p-8 bg-gray-50 dark:bg-gray-700">
      <h2 className="text-3xl font-bold mb-4">Skills</h2>
      <ul className="list-disc list-inside space-y-2">
        <li>Python</li>
        <li>HTML</li>
        <li>Microsoft Excel</li>
        <li>Microsoft Word</li>
        <li>Communication Skills</li>
      </ul>
    </section>
  );
}
