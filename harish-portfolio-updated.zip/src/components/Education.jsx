
export default function Education() {
  return (
    <section id="education" className="p-8 max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold mb-4">Education</h2>
      <ul className="space-y-4">
        <li><strong>BCA</strong> - Sri Venkateshwara University (06/2024)</li>
        <li><strong>MEC</strong> - Sri Madanapalle Junior College (06/2021)</li>
        <li><strong>Class X</strong> - Z P High School, Angallu (05/2019)</li>
      </ul>
    </section>
  );
}
